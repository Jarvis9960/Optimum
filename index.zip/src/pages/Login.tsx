import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { useAuth } from "../contexts/AuthContext";
import LoginImage from "../../public/Login image.gif";

/**
 * Login component that renders a responsive, multi-step login page.
 * It features the login form on the left and an image on the right for larger screens.
 * The entire page is fixed to the screen height to prevent scrolling.
 */
const Login = () => {
  const [step, setStep] = useState<"email" | "otp">("email");
  const [email, setEmail] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSendOtp = () => {
    // In a real app, you would send an OTP to the user's email here.
    console.log(`Sending OTP to ${email}`);
    setStep("otp");
  };

  const handleVerifyOtp = () => {
    // In a real app, you would verify the OTP from the backend.
    // For this dummy auth, we'll just log in the user.
    console.log("Verifying OTP and logging in...");
    const dummyUser = { id: "1", name: "Test User", email };
    login(dummyUser);
    navigate("/dashboard"); // Redirect to dashboard after successful login
  };

  return (
    <div className="w-full h-screen overflow-hidden lg:grid lg:grid-cols-2">
      {/* Left Panel: Login Form */}
      <div className="flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8 h-full">
        <div className="w-full max-w-md space-y-8">
          <div className="text-left">
            <h1 className="text-2xl font-bold tracking-wider">OPTIMUM</h1>
          </div>
          <div className="mx-auto grid w-full max-w-sm gap-6">
            {/* Step 1: Email Input */}
            {step === "email" && (
              <>
                <div className="grid gap-2 text-left">
                  <h2 className="text-3xl font-bold">Welcome back</h2>
                  <p className="text-balance text-muted-foreground">
                    Enter your email to receive a one-time password.
                  </p>
                </div>
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="m@example.com"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <Button
                    type="button"
                    className="w-full"
                    onClick={handleSendOtp}
                  >
                    Send OTP
                  </Button>
                </div>
              </>
            )}

            {/* Step 2: OTP Input */}
            {step === "otp" && (
              <>
                <div className="grid gap-2 text-left">
                  <h2 className="text-3xl font-bold">Check your email</h2>
                  <p className="text-balance text-muted-foreground">
                    We've sent a 4-digit code to{" "}
                    <span className="font-semibold text-primary">{email}</span>.
                  </p>
                </div>
                <div className="grid gap-4">
                  <InputOTP maxLength={4}>
                    <InputOTPGroup className="mx-auto gap-2">
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                    </InputOTPGroup>
                  </InputOTP>
                  <Button
                    type="button"
                    className="w-full"
                    onClick={handleVerifyOtp}
                  >
                    Verify OTP
                  </Button>
                  <Button variant="link" onClick={() => setStep("email")}>
                    Use a different email
                  </Button>
                </div>
              </>
            )}

            {/* Sign-up Link */}
            <div className="mt-4 text-center text-sm">
              Don't have an account?{" "}
              <a href="/register" className="underline">
                Sign up for free
              </a>
            </div>
          </div>
          {/* Step Indicator */}
          <div className="flex gap-2 pt-4">
            <div
              className={`h-1 w-full rounded-full transition-colors duration-300 ${
                step === "email" ? "bg-primary" : "bg-gray-200"
              }`}
            ></div>
            <div
              className={`h-1 w-full rounded-full transition-colors duration-300 ${
                step === "otp" ? "bg-primary" : "bg-gray-200"
              }`}
            ></div>
          </div>
        </div>
      </div>

      {/* Right Panel: Image */}
      <div className="hidden bg-muted lg:block h-full">
        <img
          src={LoginImage}
          alt="Image"
          className="h-full w-full object-cover"
        />
      </div>
    </div>
  );
};

export default Login;
